defmodule MyadTest do
  use ExUnit.Case
  doctest Myad

  test "greets the world" do
    assert Myad.hello() == :world
  end
end
